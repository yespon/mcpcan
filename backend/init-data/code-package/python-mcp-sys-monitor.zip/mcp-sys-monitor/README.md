# System Monitor MCP Server (Python)

A reference MCP server for monitoring system resources (CPU, Memory, Disk, Processes), demonstrating multiple deployment strategies.

## 🚀 Quick Start

Choose the method that matches your workflow.

### Option 1: Standard (venv + pip)
*Recommended for most users.*

```bash
# Setup & Install
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python server/main.py --transport streamable-http --port 8080
```

### Option 2: Poetry
*For developers needing strict dependency management.*

```bash
# Install & Run
poetry install
poetry run python server/main.py --transport streamable-http --port 8080
```

### Option 3: uv (High Performance)
*Fastest installation.*

```bash
# Setup & Run
uv venv
source .venv/bin/activate
uv pip install -r requirements.txt
python server/main.py --transport streamable-http --port 8080
```

### Option 4: Direct Run (Docker/CI)
*No virtual environment. Note: May require `--break-system-packages` on managed systems.*

```bash
pip install -r requirements.txt
python server/main.py --transport streamable-http --port 8080
```

---

## ⚙️ Configuration

| Flag | Default | Description |
|------|---------|-------------|
| `--transport` | `stdio` | `stdio` (CLI/Claude) or `sse` (HTTP) or `http` (HTTP) or `streamable-http` (HTTP) |
| `--port` | `8080` | Port for HTTP modes |
| `--host` | `0.0.0.0` | Host for HTTP modes |

**Examples:**
```bash
# SSE Mode (HTTP)
python server/main.py --transport sse --port 8080

# Stdio Mode (Default)
python server/main.py
```

---

## 🛠 Features (Read-Only)

- **System**: OS, kernel, uptime (`get_system_info`)
- **CPU**: Load, frequency, per-core usage (`get_cpu_usage`)
- **Memory**: RAM & Swap details (`get_memory_usage`)
- **Disk**: Partition usage & I/O (`get_disk_usage`)
- **Processes**: Top 10 resource consumers (`get_top_processes`)
