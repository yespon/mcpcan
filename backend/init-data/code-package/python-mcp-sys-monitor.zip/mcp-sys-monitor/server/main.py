import os
import threading
import time
import platform
import psutil
import json
from datetime import datetime
from fastmcp import FastMCP

import argparse

# Parse arguments first
parser = argparse.ArgumentParser(description='System Monitor MCP Server')
parser.add_argument('--transport', default=os.environ.get("FASTMCP_TRANSPORT", "stdio"), 
                    choices=['stdio', 'sse', 'http', 'streamable-http'], help='Transport mode (stdio, sse, http, or streamable-http)')
parser.add_argument('--port', type=int, default=int(os.environ.get("FASTMCP_PORT", "8080")),
                    help='Port for SSE transport')
parser.add_argument('--host', default=os.environ.get("FASTMCP_HOST", "0.0.0.0"),
                    help='Host for SSE transport')
args = parser.parse_args()

HOST = args.host
PORT = args.port
TRANSPORT = args.transport

app = FastMCP(name="system_monitor_mcp", host=HOST, port=PORT)
TOOLS = []

def register_tool(name):
    """Decorator to register tool name for startup print."""
    def decorator(func):
        TOOLS.append(name)
        return func
    return decorator

@app.tool()
@register_tool("get_system_info")
def get_system_info() -> str:
    """
    Get basic system information (OS, Version, Architecture, Uptime).
    :return: JSON string with system info.
    """
    try:
        info = {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "architecture": platform.machine(),
            "processor": platform.processor(),
            "python_version": platform.python_version(),
            "boot_time": datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S"),
            "uptime_seconds": time.time() - psutil.boot_time()
        }
        return json.dumps(info, indent=2)
    except Exception as e:
        return f"Error getting system info: {str(e)}"

@app.tool()
@register_tool("get_cpu_usage")
def get_cpu_usage() -> str:
    """
    Get detailed CPU usage information.
    Includes usage per core, frequency, and load averages.
    :return: JSON string with CPU info.
    """
    try:
        # Interval=0.1 to get a quick snapshot without blocking too long
        per_core = psutil.cpu_percent(interval=0.1, percpu=True)
        total = psutil.cpu_percent(interval=None) # Last call was 0.1s ago
        
        freq = psutil.cpu_freq()
        freq_info = {
            "current": freq.current,
            "min": freq.min,
            "max": freq.max
        } if freq else "N/A"

        # Load avg (Unix only usually)
        try:
            load_avg = psutil.getloadavg()
        except AttributeError:
            load_avg = "N/A"

        info = {
            "total_usage_percent": total,
            "per_core_usage_percent": per_core,
            "physical_cores": psutil.cpu_count(logical=False),
            "logical_cores": psutil.cpu_count(logical=True),
            "frequency_mhz": freq_info,
            "load_average_1_5_15_min": load_avg
        }
        return json.dumps(info, indent=2)
    except Exception as e:
        return f"Error getting CPU usage: {str(e)}"

@app.tool()
@register_tool("get_memory_usage")
def get_memory_usage() -> str:
    """
    Get detailed Memory usage (RAM and Swap).
    :return: JSON string with memory info.
    """
    try:
        vm = psutil.virtual_memory()
        swap = psutil.swap_memory()

        def bytes_to_gb(b):
            return round(b / (1024 ** 3), 2)

        info = {
            "virtual_memory": {
                "total_gb": bytes_to_gb(vm.total),
                "available_gb": bytes_to_gb(vm.available),
                "used_gb": bytes_to_gb(vm.used),
                "free_gb": bytes_to_gb(vm.free),
                "percent_used": vm.percent
            },
            "swap_memory": {
                "total_gb": bytes_to_gb(swap.total),
                "used_gb": bytes_to_gb(swap.used),
                "free_gb": bytes_to_gb(swap.free),
                "percent_used": swap.percent
            }
        }
        return json.dumps(info, indent=2)
    except Exception as e:
        return f"Error getting memory usage: {str(e)}"

@app.tool()
@register_tool("get_disk_usage")
def get_disk_usage() -> str:
    """
    Get Disk usage for all mounted partitions.
    :return: JSON string with disk info.
    """
    try:
        partitions = psutil.disk_partitions()
        disk_info = []
        
        for p in partitions:
            try:
                usage = psutil.disk_usage(p.mountpoint)
                disk_info.append({
                    "device": p.device,
                    "mountpoint": p.mountpoint,
                    "fstype": p.fstype,
                    "total_gb": round(usage.total / (1024 ** 3), 2),
                    "used_gb": round(usage.used / (1024 ** 3), 2),
                    "free_gb": round(usage.free / (1024 ** 3), 2),
                    "percent_used": usage.percent
                })
            except PermissionError:
                continue

        # IO Counters
        try:
            io_counters = psutil.disk_io_counters()
            io_info = {
                "read_count": io_counters.read_count,
                "write_count": io_counters.write_count,
                "read_bytes_mb": round(io_counters.read_bytes / (1024**2), 2),
                "write_bytes_mb": round(io_counters.write_bytes / (1024**2), 2)
            } if io_counters else "N/A"
        except Exception:
            io_info = "N/A"

        info = {
            "partitions": disk_info,
            "io_counters": io_info
        }
        return json.dumps(info, indent=2)
    except Exception as e:
        return f"Error getting disk usage: {str(e)}"

@app.tool()
@register_tool("get_top_processes")
def get_top_processes(limit: int = 10, sort_by: str = 'memory') -> str:
    """
    Get top N processes sorted by cpu or memory.
    :param limit: Number of processes to return (default 10).
    :param sort_by: 'cpu' or 'memory' (default 'memory').
    :return: JSON string with process list.
    """
    try:
        procs = []
        for p in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent']):
            try:
                p_info = p.info
                # Force CPU percent calculation if needed, but iterate is faster if we rely on last interval
                # psutil process cpu_percent usually needs 2 calls or interval, but here we just take what's available
                # To be more accurate we might need p.cpu_percent(interval=None) but that's slow for all procs
                procs.append(p_info)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass

        if sort_by == 'cpu':
            procs.sort(key=lambda p: p['cpu_percent'] or 0, reverse=True)
        else:
            procs.sort(key=lambda p: p['memory_percent'] or 0, reverse=True)

        top_procs = procs[:limit]
        return json.dumps(top_procs, indent=2)
    except Exception as e:
        return f"Error getting process list: {str(e)}"

def print_startup_info():
    green = "\033[92m"
    cyan = "\033[96m"
    bold = "\033[1m"
    reset = "\033[0m"
    tools_str = ", ".join(TOOLS) if TOOLS else "none"
    print(f"{green}{bold}System Monitor Service Started{reset}")
    print(f"{cyan}Tools: {tools_str}{reset}")
    print(f"{cyan}Transport: {TRANSPORT}{reset}")
    if TRANSPORT.lower() in ["sse", "http", "streamable-http"]:
        print(f"{cyan}Port: {PORT}{reset}")
        url_path = "/sse" if TRANSPORT.lower() == "sse" else "/mcp"
        print(f"{green}MCP URL: http://{HOST}:{PORT}{url_path}{reset}")
    else:
        print(f"{green}MCP URL: stdio://{reset}")

if __name__ == "__main__":
    if TRANSPORT.lower() != "stdio":
        t = threading.Thread(target=lambda: (time.sleep(1), print_startup_info()), daemon=True)
        t.start()
    
    # Filter out host/port for stdio transport to avoid TypeError
    run_kwargs = {"transport": TRANSPORT}
    if TRANSPORT.lower() != "stdio":
        run_kwargs["host"] = HOST
        run_kwargs["port"] = PORT
        
    app.run(**run_kwargs)
