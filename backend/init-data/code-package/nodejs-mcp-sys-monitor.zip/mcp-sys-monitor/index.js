import express from 'express';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import si from 'systeminformation';
import cors from 'cors';
import os from 'os';
import crypto from 'crypto';

// Argument Parsing
const args = process.argv.slice(2);
const getArg = (name, defaultVal) => {
  const index = args.findIndex(a => a === name || a.startsWith(name + '='));
  if (index === -1) return defaultVal;
  if (args[index].startsWith(name + '=')) return args[index].split('=')[1];
  return args[index + 1] || defaultVal;
};

const transportArg = getArg('--transport', process.env.FASTMCP_TRANSPORT || 'stdio');
const portArg = getArg('--port', process.env.FASTMCP_PORT || '8080');
const hostArg = getArg('--host', process.env.FASTMCP_HOST || '0.0.0.0');

const PORT = parseInt(portArg, 10);
const HOST = hostArg;

// Create MCP Server (Using Core Server Class)
const server = new Server(
  {
    name: "mcp-sys-monitor",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Helpers
const bytesToGb = (bytes) => Math.round((bytes / (1024 ** 3)) * 100) / 100;

// Tool Implementations
const tools = {
  get_system_info: {
    description: "Get basic system information (OS, Version, Architecture, Uptime).",
    inputSchema: { type: "object", properties: {} },
    handler: async () => {
      const osInfo = await si.osInfo();
      const time = si.time();
      const info = {
        system: osInfo.platform,
        release: osInfo.release,
        version: osInfo.distro,
        architecture: osInfo.arch,
        processor: os.cpus()[0].model,
        node_version: process.version,
        boot_time: new Date(time.uptime * 1000).toISOString().replace('T', ' ').split('.')[0],
        uptime_seconds: time.uptime
      };
      return { content: [{ type: "text", text: JSON.stringify(info, null, 2) }] };
    }
  },
  get_cpu_usage: {
    description: "Get detailed CPU usage information.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => {
      const currentLoad = await si.currentLoad();
      const cpu = await si.cpu();
      const cpuCurrentSpeed = await si.cpuCurrentSpeed();
      const loadAvg = os.loadavg();
      const info = {
        total_usage_percent: Math.round(currentLoad.currentLoad * 100) / 100,
        per_core_usage_percent: currentLoad.cpus.map(c => Math.round(c.load * 100) / 100),
        physical_cores: cpu.physicalCores,
        logical_cores: cpu.cores,
        frequency_mhz: { current: cpuCurrentSpeed.avg, min: cpuCurrentSpeed.min, max: cpuCurrentSpeed.max },
        load_average_1_5_15_min: loadAvg
      };
      return { content: [{ type: "text", text: JSON.stringify(info, null, 2) }] };
    }
  },
  get_memory_usage: {
    description: "Get detailed Memory usage (RAM and Swap).",
    inputSchema: { type: "object", properties: {} },
    handler: async () => {
      const mem = await si.mem();
      const info = {
        virtual_memory: {
          total_gb: bytesToGb(mem.total),
          available_gb: bytesToGb(mem.available),
          used_gb: bytesToGb(mem.used),
          free_gb: bytesToGb(mem.free),
          percent_used: Math.round((mem.used / mem.total) * 100 * 100) / 100
        },
        swap_memory: {
          total_gb: bytesToGb(mem.swaptotal),
          used_gb: bytesToGb(mem.swapused),
          free_gb: bytesToGb(mem.swapfree),
          percent_used: mem.swaptotal > 0 ? Math.round((mem.swapused / mem.swaptotal) * 100 * 100) / 100 : 0
        }
      };
      return { content: [{ type: "text", text: JSON.stringify(info, null, 2) }] };
    }
  },
  get_disk_usage: {
    description: "Get Disk usage for all mounted partitions.",
    inputSchema: { type: "object", properties: {} },
    handler: async () => {
      const fsSize = await si.fsSize();
      const diskIo = await si.disksIO();
      const disk_info = fsSize.map(d => ({
        device: d.fs,
        mountpoint: d.mount,
        fstype: d.type,
        total_gb: bytesToGb(d.size),
        used_gb: bytesToGb(d.used),
        free_gb: bytesToGb(d.size - d.used),
        percent_used: d.use
      }));
      const io_info = {
        read_count: diskIo ? diskIo.rIO : 0,
        write_count: diskIo ? diskIo.wIO : 0,
        read_bytes_mb: diskIo ? Math.round((diskIo.rIO_sec || 0) / (1024 ** 2) * 100) / 100 : 0,
        write_bytes_mb: diskIo ? Math.round((diskIo.wIO_sec || 0) / (1024 ** 2) * 100) / 100 : 0
      };
      return { content: [{ type: "text", text: JSON.stringify({ partitions: disk_info, io_counters: io_info }, null, 2) }] };
    }
  },
  get_top_processes: {
    description: "Get top N processes sorted by cpu or memory.",
    inputSchema: {
      type: "object",
      properties: {
        limit: { type: "number", default: 10, description: "Number of processes to return" },
        sort_by: { type: "string", enum: ["cpu", "memory"], default: "memory", description: "Sort by 'cpu' or 'memory'" }
      }
    },
    handler: async (args) => {
      const limit = args.limit || 10;
      const sort_by = args.sort_by || 'memory';
      const processes = await si.processes();
      let list = processes.list.map(p => ({
        pid: p.pid,
        name: p.name,
        username: p.user,
        cpu_percent: p.cpu,
        memory_percent: p.mem
      }));
      if (sort_by === 'cpu') {
        list.sort((a, b) => b.cpu_percent - a.cpu_percent);
      } else {
        list.sort((a, b) => b.memory_percent - a.memory_percent);
      }
      return { content: [{ type: "text", text: JSON.stringify(list.slice(0, limit), null, 2) }] };
    }
  }
};

// Register Tool Handlers (Using Low-Level API to avoid deprecation)
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: Object.entries(tools).map(([name, tool]) => ({
      name,
      description: tool.description,
      inputSchema: tool.inputSchema
    }))
  };
});

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const toolName = request.params.name;
  const tool = tools[toolName];
  if (!tool) {
    throw new Error(`Tool not found: ${toolName}`);
  }
  try {
    return await tool.handler(request.params.arguments || {});
  } catch (error) {
    return {
      content: [{ type: "text", text: `Error executing ${toolName}: ${error.message}` }],
      isError: true
    };
  }
});

// Start Server
async function run() {
  if (transportArg === 'stdio') {
    const transport = new StdioServerTransport();
    await server.connect(transport);
    console.error("System Monitor MCP Server running on stdio");
  } else if (transportArg === 'sse') {
    // HTTP/SSE Mode
    const app = express();
    app.use(cors());
    app.use(express.json());
    
    const mountPath = '/sse';
    const messagePath = '/messages';

    // Session Management: Map<sessionId, transport>
    const sessions = new Map();

    // SSE Endpoint (GET)
    app.get(mountPath, async (req, res) => {
      const sessionId = crypto.randomUUID();
      console.log(`New SSE connection initiated on ${mountPath}, Session ID: ${sessionId}`);

      // Manual SSE Headers
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive'
      });

      // Send endpoint event with session ID immediately
      // This tells the client where to send POST messages
      res.write(`event: endpoint\n`);
      res.write(`data: ${messagePath}?sessionId=${sessionId}\n\n`);

      // Keep-Alive Heartbeat
      const heartbeat = setInterval(() => {
        res.write(': keepalive\n\n');
      }, 15000);

      // Transport Implementation
      const transport = {
        sessionId,
        start: async () => {
          // Already started
        },
        send: async (message) => {
          res.write(`event: message\n`);
          res.write(`data: ${JSON.stringify(message)}\n\n`);
        },
        close: async () => {
          clearInterval(heartbeat);
          res.end();
        },
        onmessage: undefined,
        onclose: undefined,
        onerror: undefined
      };

      // Store session
      sessions.set(sessionId, transport);

      // Connect to MCP server
      await server.connect(transport);

      // Cleanup on close
      req.on('close', () => {
        console.log(`SSE connection closed for Session ID: ${sessionId}`);
        clearInterval(heartbeat);
        sessions.delete(sessionId);
        if (transport.onclose) transport.onclose();
      });
    });

    // Message Endpoint (POST)
    app.post(messagePath, async (req, res) => {
      let sessionId = req.query.sessionId;

      // Fallback: If no sessionId provided and only one active session exists, use it.
      if (!sessionId && sessions.size === 1) {
        sessionId = sessions.keys().next().value;
      }
      
      if (!sessionId) {
        res.status(400).send("Missing sessionId parameter");
        return;
      }

      const transport = sessions.get(sessionId);
      
      if (transport) {
        if (transport.onmessage) {
          try {
            await transport.onmessage(req.body);
            res.status(202).send("Accepted");
          } catch (e) {
            console.error("Error handling message:", e);
            res.status(500).send(e.message);
          }
        } else {
          res.status(500).send("Transport not ready");
        }
      } else {
        res.status(404).send(`Session not found: ${sessionId}`);
      }
    });

    app.listen(PORT, HOST, () => {
      console.log(`System Monitor MCP Server running on http://${HOST}:${PORT}${mountPath} (Transport: ${transportArg})`);
    });
  } else {
    console.error(`Unknown transport: ${transportArg}. Supported: stdio, sse`);
    process.exit(1);
  }
}

run().catch(console.error);
