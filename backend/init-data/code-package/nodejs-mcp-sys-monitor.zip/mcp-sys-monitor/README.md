# System Monitor MCP Server (Node.js)

A Node.js implementation of the System Monitor MCP Server, mirroring the functionality of the Python version. It provides tools to monitor CPU, Memory, Disk, and Processes.

## 🚀 Quick Start

Ensure you have Node.js (v18+ recommended) installed.

### Option 1: npm (Standard)

```bash
# Install
npm install

# Run
npm start --transport=sse --port=8080
```

### Option 2: pnpm (Efficient)

```bash
# Install
pnpm install

# Run
pnpm start --transport=sse --port=8080
```

### Option 3: Yarn (Classic)

```bash
# Install
yarn install

# Run
yarn start --transport=sse --port=8080
```

### Option 4: Node.js (Direct)

```bash
# Install dependencies first
npm install

# Run directly
node index.js --transport=sse --port=8080
```

---

## ⚙️ Configuration

| Flag | Default | Description |
|------|---------|-------------|
| `--transport` | `stdio` | Transport mode: `stdio`, `sse`|
| `--port` | `8080` | Port for SSE/HTTP transport |
| `--host` | `0.0.0.0` | Host for SSE/HTTP transport |

## 🛠 Features

- **get_system_info**: OS, kernel, uptime
- **get_cpu_usage**: Load, frequency, per-core usage
- **get_memory_usage**: RAM & Swap details
- **get_disk_usage**: Partition usage & I/O
- **get_top_processes**: Top N resource consumers
